import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TimersService } from '../services/timers.service';

@Component({
  selector: 'app-lecturas',
  templateUrl: './lecturas.component.html',
  styleUrls: ['./lecturas.component.scss']
})
export class LecturasComponent implements OnInit {

  constructor(private service: TimersService, private router: Router) {}
  value = 0;
  ngOnInit(): void {
      this.startTimer();
  }

  startTimer() {
      let total = this.service.read_time
      let interval = setInterval(() => {
          this.service.read_time -= 1
          this.value += 100 / total
          if (this.service.read_time == 0) {
              clearInterval(interval);
              this.router.navigate(['/']); 
          }
      }, 100) // esto se hace porque no funciona bien al actualizar por milisegundo debido a la latencia
      //actualiza cada 100 milisegundos por eso los segundos totales se multiplican por 10 (100ms = 0.1s)
  }

}
