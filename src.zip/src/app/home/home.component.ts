import { Component, OnInit } from '@angular/core';
import { TimersService } from '../services/timers.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private service: TimersService) { }
  ngOnInit(): void {
    
    this.homework = this.service.homework;
    console.log(this.homework)
  }
  video_timer = this.service.video_time
  read_timer = this.service.read_time
  homework = this.service.homework;
}
