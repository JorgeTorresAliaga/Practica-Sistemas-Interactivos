import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class TimersService {
  private video_timer = {min: 0, sec: 5};
  private read_timer = {min: 0, sec: 5};
  public homework = false;
  public video_time = this.getTotalVideos();
  public read_time = this.getTotalReading();
  
  constructor() {}
  
  getTotalVideos():number {
    return (this.video_timer.min * 60 + this.video_timer.sec) * 10;
  }
  getTotalReading():number {
    return (this.read_timer.min * 60 + this.read_timer.sec) * 10;
  }
}



