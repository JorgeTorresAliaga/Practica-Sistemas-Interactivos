import { Component, OnInit } from '@angular/core';
import { TimersService } from '../services/timers.service';

@Component({
  selector: 'app-deberes',
  templateUrl: './deberes.component.html',
  styleUrls: ['./deberes.component.scss']
})
export class DeberesComponent implements OnInit {

  constructor(private service: TimersService) { }
  homework = this.service.homework;
  ngOnInit(): void { console.log(this.homework)
  }
  

  accept_homework() {
    this.service.homework = true;
    this.homework = this.service.homework;
    console.log(this.homework)
  }

}
